﻿using System.Reflection;
using System.Reflection.Metadata.Ecma335;
using Microsoft.AspNetCore.Mvc;
using Uber.SERV.Restaurant.Data;
using Uber.SERV.Restaurant.Models;
using Uber.SERV.Restaurant.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Uber.SERV.Restaurant.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RestaurantController : ControllerBase
    {
        private readonly IRestaurantService _restaurantService;

        public RestaurantController(IRestaurantService restaurantService)
        {
            _restaurantService = restaurantService ?? throw new ArgumentNullException(nameof(restaurantService));
        }
        /// <summary>
        /// Get all restaurants
        /// </summary>
        /// <returns>return the list of restaurants</returns>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_restaurantService.GetRestaurants());
        }

        /// <summary>
        /// Get restaurant by ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Return the restaurant with the passed ID</returns>
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            return _restaurantService.GetRestaurant(id) != null ? Ok(_restaurantService.GetRestaurant(id)) : NoContent();
        }

        /// <summary>
        /// Add restaurants
        /// </summary>
        /// <param name="restaurant"></param>
        /// <returns>Return the added restaurant</returns>
        [HttpPost]
        public IActionResult Post([FromBody] Models.Restaurant restaurant)
        {
            return Ok(_restaurantService.AddRestaurant(restaurant));
        }

        /// <summary>
        /// Update the restaurant
        /// </summary>
        /// <param name="restaurant"></param>
        /// <returns>Return the updated restaurant</returns>
        [HttpPut]
        public IActionResult Put([FromBody] Models.Restaurant restaurant)
        {
            return Ok(_restaurantService.UpdateRestaurant(restaurant));
        }

        /// <summary>
        /// Delete the restaurant with the passed ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var result = _restaurantService.DeleteRestaurant(id);

            return result.HasValue & result == true ? Ok($"restaurant with ID:{id} got deleted successfully.")
                : BadRequest($"Unable to delete the restaurant with ID:{id}.");
        }
    }
}