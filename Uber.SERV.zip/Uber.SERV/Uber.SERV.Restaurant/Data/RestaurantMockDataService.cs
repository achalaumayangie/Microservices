﻿namespace Uber.SERV.Restaurant.Data
{
    public static class RestaurantMockDataService
    {
        public static List<Models.Restaurant> Restaurants = new List<Models.Restaurant>()
        {
            new Models.Restaurant { Id = 1, Name = "KFC", Location = "Kaduwela", Opentime = "07.30 a.m" },
            new Models.Restaurant { Id = 2, Name = "Mr. Koththu Grand", Location = "Malabe", Opentime = "08.30 a.m" },
            new Models.Restaurant { Id = 3, Name = "Treats & Stuff", Location = "Baththaramulla", Opentime = "09.00 a.m" },
            new Models.Restaurant { Id = 4, Name = "Bimsara", Location = "Pelawatta", Opentime = "09.00 a.m" },
            new Models.Restaurant { Id = 5, Name = "Pasindu", Location = "Rajagiriya", Opentime = "09.30 a.m" }
        };
    }
}