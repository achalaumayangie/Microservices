﻿using Uber.SERV.Restaurant.Data;
using Uber.SERV.Restaurant.Models;

namespace Uber.SERV.Restaurant.Services
{
    public class RestaurantService:IRestaurantService
    {
        public List<Models.Restaurant> GetRestaurants()
        {
            return RestaurantMockDataService.Restaurants;
        }

        public Models.Restaurant? GetRestaurant(int id)
        {
            return RestaurantMockDataService.Restaurants.FirstOrDefault(x => x.Id == id);
        }

        public Models.Restaurant? AddRestaurant(Models.Restaurant restaurant)
        {
            RestaurantMockDataService.Restaurants.Add(restaurant);
            return restaurant;
        }
        public Models.Restaurant? UpdateRestaurant(Models.Restaurant restaurant)
        {
            Models.Restaurant selectedRestaurant = RestaurantMockDataService.Restaurants.FirstOrDefault(x => x.Id == restaurant.Id);
            if (selectedRestaurant != null)
            {
                selectedRestaurant.Location = restaurant.Location;
                selectedRestaurant.Opentime = restaurant.Opentime;
                selectedRestaurant.Name = restaurant.Name;
                return selectedRestaurant;
            }

            return selectedRestaurant;
        }

        public bool? DeleteRestaurant(int id)
        {
            Models.Restaurant selectedRestaurant = RestaurantMockDataService.Restaurants.FirstOrDefault(x => x.Id == id);
            if (selectedRestaurant != null)
            {
                RestaurantMockDataService.Restaurants.Remove(selectedRestaurant);
                return true;
            }
            return false;
        }
    }
}