﻿namespace Uber.SERV.Restaurant.Services
{
    public interface IRestaurantService
    {
        List<Models.Restaurant> GetRestaurants();
        Models.Restaurant? GetRestaurant(int id);
        Models.Restaurant? AddRestaurant(Models.Restaurant restaurant);
        Models.Restaurant? UpdateRestaurant(Models.Restaurant restaurant);
        bool? DeleteRestaurant(int id);
    }
}
