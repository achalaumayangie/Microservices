﻿using System.Reflection;

namespace Uber.SERV.Customer.Data
{
    public static class CustomerMockDataService
    {
        public static List<Models.Customer> Customers = new List<Models.Customer>()
        {
            new Models.Customer { Id = 1, Name = "Dilshi", Address = "Agalawaththa", Phone = "076789898", Email = "dilshi@gmail.com" },
            new Models.Customer { Id = 2, Name = "Devindi", Address = "Mathugama", Phone = "0712347648", Email = "devindi@gmail.com" },
            new Models.Customer { Id = 3, Name = "Lumbini", Address = "Bonegala", Phone = "0789875646", Email = "lumbini@gmail.com" },
            new Models.Customer { Id = 4, Name = "Bimsara", Address = "Gampaha", Phone = "0743467890", Email = "bimsara@gmail.com" },
            new Models.Customer { Id = 5, Name = "Pasindu", Address = "Kithulgoda", Phone = "0707898764", Email = "pasindu@gmail.com" }
        };
    }
}