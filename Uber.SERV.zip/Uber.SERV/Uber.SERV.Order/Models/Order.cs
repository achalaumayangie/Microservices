﻿namespace Uber.SERV.Order.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string? FoodName { get; set; }
        public string? Size { get; set; }
        public int Amount { get; set; }
    }
}
