﻿using Uber.SERV.Order.Data;
using Uber.SERV.Order.Models;

namespace Uber.SERV.Order.Services
{
    public class OrderService : IOrderService
    {
        public List<Models.Order> GetOrders()
        {
            return OrderMockDataService.Orders;
        }

        public Models.Order? GetOrder(int id)
        {
            return OrderMockDataService.Orders.FirstOrDefault(x => x.Id == id);
        }

        public Models.Order? AddOrder(Models.Order order)
        {
            OrderMockDataService.Orders.Add(order);
            return order;
        }

        public Models.Order? UpdateOrder(Models.Order order)
        {
            Models.Order selectedOrder = OrderMockDataService.Orders.FirstOrDefault(x => x.Id == order.Id);
            if (selectedOrder != null)
            {
                selectedOrder.Size = order.Size;
                selectedOrder.Amount = order.Amount;
                selectedOrder.FoodName = order.FoodName;
                return selectedOrder;
            }

            return selectedOrder;
        }

        public bool? DeleteOrder(int id)
        {
            Models.Order selectedOrder = OrderMockDataService.Orders.FirstOrDefault(x => x.Id == id);
            if (selectedOrder != null)
            {
                OrderMockDataService.Orders.Remove(selectedOrder);
                return true;
            }
            return false;
        }
    }
}
