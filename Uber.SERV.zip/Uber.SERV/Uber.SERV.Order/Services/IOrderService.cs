﻿namespace Uber.SERV.Order.Services
{
    public interface IOrderService
    {
        List<Models.Order> GetOrders();
        Models.Order? GetOrder(int id);
        Models.Order? AddOrder(Models.Order order);
        Models.Order? UpdateOrder(Models.Order order);
        bool? DeleteOrder(int id);

    }
}
