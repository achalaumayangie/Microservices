﻿using System.Reflection.Metadata.Ecma335;
using Microsoft.AspNetCore.Mvc;
using Uber.SERV.Order.Data;
using Uber.SERV.Order.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Uber.SERV.Order.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService ?? throw new ArgumentNullException(nameof(orderService));
        }


        /// <summary>
        /// Get all orders
        /// </summary>
        /// <returns>return the list of orders</returns>
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_orderService.GetOrders());
        }

        /// <summary>
        /// Get order by ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Return the order with the passed ID</returns>
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            return _orderService.GetOrder(id) != null ? Ok(_orderService.GetOrder(id)) : NoContent();
        }

        /// <summary>
        /// Add orders
        /// </summary>
        /// <param name="order"></param>
        /// <returns>Return the added order</returns>
        [HttpPost]
        public IActionResult Post([FromBody] Models.Order order)
        {
            return Ok(_orderService.AddOrder(order));
        }

        /// <summary>
        /// Update the order
        /// </summary>
        /// <param name="order"></param>
        /// <returns>Return the updated order</returns>
        [HttpPut]
        public IActionResult Put([FromBody] Models.Order order)
        {
            return Ok(_orderService.UpdateOrder(order));
        }

        /// <summary>
        /// Delete the order with the passed ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var result = _orderService.DeleteOrder(id);

            return result.HasValue & result == true ? Ok($"order with ID:{id} got deleted successfully.")
                : BadRequest($"Unable to delete the order with ID:{id}.");
        }
    }
}