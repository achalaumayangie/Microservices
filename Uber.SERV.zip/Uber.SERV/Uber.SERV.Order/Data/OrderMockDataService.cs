﻿using System.Reflection;

namespace Uber.SERV.Order.Data
{
    public static class OrderMockDataService
    {
        public static List<Models.Order> Orders = new List<Models.Order>()
        {
            new Models.Order { Id = 1, FoodName = "Noodle", Size = "Large", Amount = 2 },
            new Models.Order { Id = 2, FoodName = "Soup", Size = "Medium", Amount = 3 },
            new Models.Order { Id = 3, FoodName = "Salad", Size = "Small", Amount = 1 },
            new Models.Order { Id = 4, FoodName = "Cake", Size = "Small", Amount = 2 },
            new Models.Order { Id = 5, FoodName = "Cookies", Size = "Large", Amount = 10 }
        };

    }
}